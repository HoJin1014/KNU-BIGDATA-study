This document is written for the guide of the T3Q.ai platform, 
and T3Q Co., Ltd. has the legal authority for matters other than the stated copyright.

The following components are under Apache License 2.0 license
- code components

@misc{tensorflowmodelgarden2020,
  author = {Hongkun Yu, Chen Chen, Xianzhi Du, Yeqing Li, Abdullah Rashwan, Le Hou, Pengchong Jin, Fan Yang,
            Frederick Liu, Jaeyoun Kim, and Jing Li},
  title = {{TensorFlow Model Garden}},
  howpublished = {\url{https://github.com/tensorflow/models}},
  year = {2020}
}

----------------------------------------------------------------------
- 데이터셋 라이선스: 
- 코드 라이선스: Apache License 2.0
----------------------------------------------------------------------
