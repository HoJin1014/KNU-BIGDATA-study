This document is written for the guide of the T3Q.ai platform, 
and T3Q Co., Ltd. has the legal authority for matters other than the stated copyright.

The following components are under Apache 2.0 License
- code components

----------------------------------------------------------------------
- 데이터셋 라이선스: 
- 코드 라이선스: Apache-2.0 license
----------------------------------------------------------------------
